"use client";

import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { Logo } from "@/components/shared/logo";
import { GlowButton } from "@/components/ui/glow-button";

const LINKS = [
  { href: "#fonctionnalites", label: "Fonctionnalités" },
  { href: "#matieres", label: "Matières" },
  { href: "#tarifs", label: "Tarifs" },
];

/** Navbar sticky. Menu burger sous 1024px (à 768px, tout ne tient pas sur une ligne). */
export function Navbar() {
  const [open, setOpen] = useState(false);

  // Échap ferme le menu mobile (accessibilité clavier)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <header className="sticky top-0 z-50 border-b border-border/70 bg-background/85 backdrop-blur-md">
      <nav aria-label="Navigation principale" className="container-page flex h-16 items-center justify-between">
        <Logo />

        <ul className="hidden items-center gap-1 lg:flex">
          {LINKS.map((l) => (
            <li key={l.href}>
              <a href={l.href} className="rounded-pill px-4 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden items-center gap-2 lg:flex">
          <GlowButton href="/connexion" variant="ghost" size="sm">Se connecter</GlowButton>
          <GlowButton href="/inscription" size="sm">Créer un compte</GlowButton>
        </div>

        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          aria-controls="menu-mobile"
          aria-label={open ? "Fermer le menu" : "Ouvrir le menu"}
          className="grid h-11 w-11 place-items-center rounded-pill border border-border bg-card lg:hidden"
        >
          {open ? <X aria-hidden className="h-5 w-5" /> : <Menu aria-hidden className="h-5 w-5" />}
        </button>
      </nav>

      {open && (
        <div id="menu-mobile" className="border-t border-border bg-background lg:hidden">
          <div className="container-page flex flex-col gap-1 py-4">
            {LINKS.map((l) => (
              <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="rounded-card px-3 py-3 text-base font-medium hover:bg-primary-soft">
                {l.label}
              </a>
            ))}
            <div className="mt-3 flex flex-col gap-2 sm:flex-row">
              <GlowButton href="/connexion" variant="secondary" className="flex-1">Se connecter</GlowButton>
              <GlowButton href="/inscription" className="flex-1">Créer un compte</GlowButton>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
