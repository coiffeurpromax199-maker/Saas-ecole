import { CheckCircle2, PenLine, Upload } from "lucide-react";
import { Reveal } from "@/components/shared/reveal";
import { SectionHeading } from "@/components/shared/section-heading";

const STEPS = [
  { icon: Upload, title: "Upload ton cours", text: "Envoie ta leçon en PDF ou en photo. Tu reçois un résumé clair des points à retenir." },
  { icon: PenLine, title: "Fais tes exercices", text: "Des exercices sur le chapitre que tu viens d’importer, à ton rythme." },
  { icon: CheckCircle2, title: "Reçois ta correction", text: "Une correction détaillée qui explique tes erreurs et te dit quoi réviser ensuite." },
];

export function HowItWorks() {
  return (
    // id="fonctionnalites" : cible du lien « Fonctionnalités » de la navbar
    <section id="fonctionnalites" aria-labelledby="how-title" className="bg-card/60 py-16 sm:py-24">
      <div id="comment-ca-marche" className="container-page scroll-mt-20">
        <Reveal>
          <SectionHeading id="how-title" title="Comment ça marche" description="Trois étapes, de ton cahier à ta correction." />
        </Reveal>
        {/* Ici, l'ordre compte : la liste est numérotée */}
        <ol className="mt-12 grid gap-6 md:grid-cols-3">
          {STEPS.map(({ icon: Icon, title, text }, i) => (
            <li key={title}>
              <Reveal delay={i * 80} className="h-full">
                <div className="card-glow h-full p-6">
                  <div className="flex items-center gap-3">
                    <span className="grid h-8 w-8 place-items-center rounded-full bg-primary-dark text-sm font-bold text-white" aria-label={`Étape ${i + 1}`}>
                      {i + 1}
                    </span>
                    <Icon aria-hidden className="h-6 w-6 text-primary-dark" />
                  </div>
                  <h3 className="mt-5 font-sans text-lg font-semibold">{title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{text}</p>
                </div>
              </Reveal>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
