import { BookOpen, FlaskConical, Globe, Languages, Lightbulb, MessageSquareText, Sigma, TrendingUp, type LucideIcon } from "lucide-react";
import { Reveal } from "@/components/shared/reveal";
import { SectionHeading } from "@/components/shared/section-heading";

type Tone = "primary" | "accent" | "success" | "warning" | "danger";

// Classes complètes (pas de concaténation dynamique) pour que Tailwind les détecte.
const TONES: Record<Tone, string> = {
  primary: "bg-primary-soft text-primary-dark",
  accent: "bg-accent-soft text-accent-dark",
  success: "bg-success-soft text-success-dark",
  warning: "bg-warning-soft text-warning-dark",
  danger: "bg-danger-soft text-danger-dark",
};

const SUBJECTS: { name: string; desc: string; icon: LucideIcon; tone: Tone }[] = [
  { name: "Mathématiques", desc: "Cours, méthodes et exercices", icon: Sigma, tone: "primary" },
  { name: "Français", desc: "Dissertation et commentaire", icon: BookOpen, tone: "danger" },
  { name: "Philosophie", desc: "Notions, textes et dissertation", icon: Lightbulb, tone: "warning" },
  { name: "Histoire-Géographie", desc: "Repères et compositions", icon: Globe, tone: "success" },
  { name: "Économie", desc: "Concepts et analyse de documents", icon: TrendingUp, tone: "accent" },
  { name: "Espagnol", desc: "Grammaire et expression", icon: Languages, tone: "danger" },
  { name: "Physique-Chimie", desc: "Lois et exercices d’application", icon: FlaskConical, tone: "primary" },
  { name: "Anglais", desc: "Vocabulaire et compréhension", icon: MessageSquareText, tone: "accent" },
];

export function Subjects() {
  return (
    <section id="matieres" aria-labelledby="matieres-title" className="py-16 sm:py-24">
      <div className="container-page">
        <Reveal>
          <SectionHeading id="matieres-title" title="Toutes tes matières au même endroit" description="Huit matières de la série L2, avec un suivi séparé pour chacune." />
        </Reveal>
        <ul className="mt-12 grid grid-cols-1 gap-4 min-[480px]:grid-cols-2 lg:grid-cols-4">
          {SUBJECTS.map(({ name, desc, icon: Icon, tone }, i) => (
            <li key={name}>
              <Reveal delay={(i % 4) * 60} className="h-full">
                {/* group → déclenche la micro-animation de l'icône au survol de la carte */}
                <article className="card-glow group h-full p-5">
                  <span className={`grid h-12 w-12 place-items-center rounded-xl transition-transform duration-200 ease-out group-hover:-rotate-6 group-hover:scale-110 motion-reduce:transition-none motion-reduce:group-hover:transform-none ${TONES[tone]}`}>
                    <Icon aria-hidden className="h-6 w-6" />
                  </span>
                  <h3 className="mt-4 font-sans text-base font-semibold">{name}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
                </article>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
