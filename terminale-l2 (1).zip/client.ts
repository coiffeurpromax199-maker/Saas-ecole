import { createBrowserClient } from "@supabase/ssr";

/**
 * Client Supabase côté navigateur.
 * ⚠️ Préparé mais NON utilisé à cette étape : aucun import dans l'app.
 */
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
