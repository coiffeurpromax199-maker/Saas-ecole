import { Reveal } from "@/components/shared/reveal";
import { GlowButton } from "@/components/ui/glow-button";

export function FinalCta() {
  return (
    // id="tarifs" provisoire : la grille tarifaire sera ajoutée dans une étape ultérieure
    <section id="tarifs" aria-labelledby="cta-title" className="px-4 pb-16 sm:px-6 sm:pb-24">
      <Reveal className="mx-auto max-w-6xl">
        <div className="relative overflow-hidden rounded-card bg-foreground px-6 py-14 text-center sm:px-12 sm:py-20">
          <div aria-hidden className="absolute -left-20 -top-20 h-64 w-64 rounded-full bg-primary/40 blur-3xl" />
          <div aria-hidden className="absolute -bottom-24 -right-16 h-64 w-64 rounded-full bg-accent/30 blur-3xl" />
          <div className="relative">
            <h2 id="cta-title" className="mx-auto max-w-2xl text-3xl font-semibold leading-tight text-white sm:text-4xl">
              Prépare ton Bac L2 dès aujourd’hui
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-base text-slate-300 sm:text-lg">
              Crée ton compte gratuitement et importe ton premier cours en quelques minutes.
            </p>
            <div className="mt-8 flex justify-center">
              <GlowButton href="/inscription" variant="secondary" size="lg">Commencer gratuitement</GlowButton>
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
