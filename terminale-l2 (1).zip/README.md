# Terminale L2

SaaS éducatif pour les élèves de Terminale L2 (Sénégal). Étape 1 : fondations + landing page.

```bash
npm install
cp .env.example .env.local   # Supabase : pas encore utilisé
npm run dev
```
