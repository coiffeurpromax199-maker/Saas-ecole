import Link from "next/link";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

/**
 * Bouton « glow » réutilisable.
 * - L'effet (box-shadow + pulsation) vit dans globals.css (.glow-btn) pour pouvoir
 *   être coupé proprement via prefers-reduced-motion.
 * - Disabled : opacité 50 %, aucun glow (le sélecteur CSS exclut :disabled).
 * - Rend un <Link> si `href` est fourni, sinon un <button>.
 */
const glowButton = cva(
  [
    "glow-btn inline-flex select-none items-center justify-center gap-2 whitespace-nowrap",
    "rounded-pill border font-semibold",
    "disabled:pointer-events-none disabled:opacity-50",
  ],
  {
    variants: {
      variant: {
        primary: "border-primary-dark bg-primary-dark text-white hover:border-accent hover:bg-primary-darker",
        secondary: "border-border bg-card text-foreground hover:border-primary",
        ghost: "border-transparent bg-transparent text-foreground hover:border-primary hover:bg-primary-soft/60",
      },
      size: {
        sm: "h-10 px-5 text-sm",
        md: "h-11 px-6 text-sm",
        lg: "h-12 px-8 text-base",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  }
);

type Common = VariantProps<typeof glowButton> & { className?: string; children: React.ReactNode };
type AsLink = Common & { href: string } & Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, "href" | "className">;
type AsButton = Common & { href?: undefined } & Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "className">;

export function GlowButton(props: AsLink | AsButton) {
  const { variant, size, className, children, ...rest } = props;
  const classes = cn(glowButton({ variant, size }), className);

  if ("href" in rest && rest.href !== undefined) {
    return (
      <Link {...(rest as Omit<AsLink, keyof Common>)} className={classes}>
        {children}
      </Link>
    );
  }
  return (
    <button type="button" {...(rest as Omit<AsButton, keyof Common>)} className={classes}>
      {children}
    </button>
  );
}
