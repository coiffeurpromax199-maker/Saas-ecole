import { GraduationCap, ShieldCheck, Target } from "lucide-react";
import { Reveal } from "@/components/shared/reveal";
import { SectionHeading } from "@/components/shared/section-heading";

const REASONS = [
  { icon: ShieldCheck, title: "De la rigueur", text: "Des explications structurées et des corrections exigeantes, comme on l’attend le jour de l’examen." },
  { icon: GraduationCap, title: "Adapté au programme sénégalais", text: "Les contenus suivent la série L2 et les attentes du Bac au Sénégal, matière par matière." },
  { icon: Target, title: "Une correction personnalisée", text: "Chaque réponse est corrigée selon ton niveau, avec des conseils pour progresser là où tu bloques." },
];

export function WhyUs() {
  return (
    <section aria-labelledby="why-title" className="py-16 sm:py-24">
      <div className="container-page">
        <Reveal>
          <SectionHeading id="why-title" title="Pourquoi Terminale L2" />
        </Reveal>
        <ul className="mt-12 grid gap-8 md:grid-cols-3">
          {REASONS.map(({ icon: Icon, title, text }, i) => (
            <li key={title}>
              <Reveal delay={i * 80}>
                <Icon aria-hidden className="h-8 w-8 text-primary-dark" />
                <h3 className="mt-4 text-xl font-semibold">{title}</h3>
                <p className="mt-2 leading-relaxed text-muted-foreground">{text}</p>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
