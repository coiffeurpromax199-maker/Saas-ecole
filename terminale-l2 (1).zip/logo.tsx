import Link from "next/link";

export function Logo({ className = "" }: { className?: string }) {
  return (
    <Link href="/" aria-label="Terminale L2 — accueil" className={`inline-flex items-center gap-2.5 rounded-pill ${className}`}>
      <span aria-hidden className="grid h-9 w-9 place-items-center rounded-[10px] bg-gradient-to-br from-primary to-accent font-display text-sm font-bold text-white shadow-soft">
        L2
      </span>
      <span className="font-display text-xl font-semibold tracking-tight">Terminale L2</span>
    </Link>
  );
}
