import { CheckCircle2, FileText, Sparkles } from "lucide-react";

/** Mockup abstrait 100 % CSS/JSX (aucune image). Décoratif → aria-hidden. */
export function HeroMockup() {
  return (
    <div aria-hidden className="relative mx-auto w-full max-w-md">
      <div className="absolute -inset-4 -z-10 rounded-[28px] bg-gradient-to-br from-primary/20 via-transparent to-accent/25 blur-2xl" />

      <div className="rounded-card border border-border bg-card p-5 shadow-lift">
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary-soft text-primary-dark">
            <FileText className="h-5 w-5" />
          </span>
          <div>
            <p className="text-sm font-semibold">Philosophie — La conscience</p>
            <p className="text-xs text-muted-foreground">Cours importé</p>
          </div>
        </div>

        {/* Résumé généré (barres = texte factice) */}
        <div className="mt-5 space-y-2.5">
          <div className="h-2.5 w-11/12 rounded-pill bg-border" />
          <div className="h-2.5 w-full rounded-pill bg-border" />
          <div className="h-2.5 w-3/4 rounded-pill bg-border" />
        </div>

        <div className="mt-5 rounded-xl bg-primary-soft p-4">
          <p className="flex items-center gap-1.5 text-xs font-semibold text-primary-darker">
            <Sparkles className="h-3.5 w-3.5" /> Exercice 1
          </p>
          <div className="mt-3 space-y-2">
            <div className="flex items-center gap-2 rounded-lg border border-success bg-success-soft px-3 py-2 text-xs font-medium text-success-dark">
              <CheckCircle2 className="h-4 w-4" /> Réponse correcte
            </div>
            <div className="h-8 rounded-lg border border-border bg-card" />
          </div>
        </div>
      </div>

      {/* Pastilles flottantes (animation coupée si reduced-motion grâce à motion-safe) */}
      <div className="absolute -right-3 -top-4 rounded-pill border border-border bg-card px-4 py-2 text-xs font-semibold shadow-soft motion-safe:animate-float sm:-right-6">
        <span className="text-success-dark">Progression +12 %</span>
      </div>
      <div className="absolute -bottom-4 -left-3 rounded-pill border border-border bg-card px-4 py-2 text-xs font-semibold shadow-soft motion-safe:animate-float [animation-delay:1.5s] sm:-left-6">
        <span className="text-primary-dark">Résumé prêt</span>
      </div>
    </div>
  );
}
