import { ArrowRight, Play } from "lucide-react";
import { GlowButton } from "@/components/ui/glow-button";
import { HeroMockup } from "./hero-mockup";

export function Hero() {
  return (
    <section aria-labelledby="hero-title" className="relative overflow-hidden">
      {/* Halos de fond décoratifs, très légers */}
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -top-24 left-1/4 h-96 w-96 rounded-full bg-primary/15 blur-3xl" />
        <div className="absolute right-0 top-40 h-72 w-72 rounded-full bg-accent/20 blur-3xl" />
      </div>

      <div className="container-page grid items-center gap-14 py-14 sm:py-20 lg:grid-cols-[1.1fr_0.9fr] lg:gap-10 lg:py-28">
        <div>
          <h1 id="hero-title" className="text-4xl font-semibold leading-[1.1] sm:text-5xl lg:text-6xl">
            Réussis ton Bac L2 avec un prof particulier IA
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground">
            Upload ton cours, reçois un résumé clair, fais des exercices corrigés et progresse matière par matière.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <GlowButton href="/inscription" size="lg">
              Commencer gratuitement <ArrowRight aria-hidden className="h-4 w-4" />
            </GlowButton>
            <GlowButton href="#comment-ca-marche" variant="ghost" size="lg">
              <Play aria-hidden className="h-4 w-4" /> Voir une démo
            </GlowButton>
          </div>
        </div>
        <HeroMockup />
      </div>
    </section>
  );
}
