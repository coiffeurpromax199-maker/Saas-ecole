import type { Config } from "tailwindcss";
import { fontFamily } from "tailwindcss/defaultTheme";

/**
 * Design system « Terminale L2 ».
 * Chaque couleur d'état a 3 niveaux : DEFAULT (fonds, glow), dark (texte/icônes, contraste AA),
 * soft (fond teinté discret).
 */
const config: Config = {
  darkMode: "class", // prêt pour un futur mode sombre, non activé pour l'instant
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        background: "#F7F8FC",
        foreground: "#0F172A",
        card: "#FFFFFF",
        border: "#E2E8F0",
        "muted-foreground": "#475569", // 7:1 sur le fond → AA/AAA
        primary: { DEFAULT: "#6366F1", dark: "#4F46E5", darker: "#4338CA", soft: "#EEF0FF" },
        accent: { DEFAULT: "#22D3EE", dark: "#0E7490", soft: "#E3F9FD" },
        success: { DEFAULT: "#10B981", dark: "#047857", soft: "#DDF7EE" },
        warning: { DEFAULT: "#F59E0B", dark: "#B45309", soft: "#FEF1D6" },
        danger: { DEFAULT: "#EF4444", dark: "#B91C1C", soft: "#FDE6E6" },
      },
      fontFamily: {
        sans: ["var(--font-inter)", ...fontFamily.sans],
        display: ["var(--font-fraunces)", ...fontFamily.serif],
      },
      borderRadius: { card: "16px", pill: "999px" },
      boxShadow: {
        soft: "0 1px 2px rgb(15 23 42 / 0.04), 0 4px 16px rgb(15 23 42 / 0.06)",
        lift: "0 2px 4px rgb(15 23 42 / 0.04), 0 14px 34px rgb(99 102 241 / 0.16)",
        glow: "0 0 0 1px rgb(99 102 241 / 0.5), 0 0 24px rgb(99 102 241 / 0.3), 0 0 44px rgb(34 211 238 / 0.18)",
      },
      keyframes: {
        float: { "0%, 100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-8px)" } },
      },
      animation: { float: "float 6s ease-in-out infinite" },
    },
  },
  plugins: [],
};

export default config;
