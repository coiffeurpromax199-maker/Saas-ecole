import { Logo } from "@/components/shared/logo";

const COLS = [
  { title: "Produit", links: [["Fonctionnalités", "#fonctionnalites"], ["Matières", "#matieres"], ["Tarifs", "#tarifs"]] },
  { title: "Compte", links: [["Se connecter", "/connexion"], ["Créer un compte", "/inscription"]] },
];

export function Footer() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="container-page grid gap-10 py-12 sm:grid-cols-2 lg:grid-cols-[1.5fr_1fr_1fr]">
        <div>
          <Logo />
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
            Le prof particulier IA des élèves de Terminale L2 au Sénégal.
          </p>
        </div>
        {COLS.map((col) => (
          <nav key={col.title} aria-label={col.title}>
            <h2 className="font-sans text-sm font-semibold">{col.title}</h2>
            <ul className="mt-4 space-y-2">
              {col.links.map(([label, href]) => (
                <li key={href}>
                  <a href={href} className="rounded text-sm text-muted-foreground transition-colors hover:text-foreground">{label}</a>
                </li>
              ))}
            </ul>
          </nav>
        ))}
      </div>
      <div className="border-t border-border">
        <p className="container-page py-5 text-sm text-muted-foreground">© {new Date().getFullYear()} Terminale L2. Tous droits réservés.</p>
      </div>
    </footer>
  );
}
