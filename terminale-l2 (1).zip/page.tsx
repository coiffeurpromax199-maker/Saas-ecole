import { Footer } from "@/components/layout/footer";
import { Navbar } from "@/components/layout/navbar";
import { FinalCta } from "@/components/sections/final-cta";
import { Hero } from "@/components/sections/hero";
import { HowItWorks } from "@/components/sections/how-it-works";
import { Subjects } from "@/components/sections/subjects";
import { WhyUs } from "@/components/sections/why-us";

/** Landing publique « / » : assemblage des sections (Server Component). */
export default function HomePage() {
  return (
    <>
      <Navbar />
      <main id="contenu">
        <Hero />
        <Subjects />
        <HowItWorks />
        <WhyUs />
        <FinalCta />
      </main>
      <Footer />
    </>
  );
}
